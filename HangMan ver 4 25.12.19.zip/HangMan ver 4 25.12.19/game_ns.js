var gm = {}
var creation = false;

gm.init = function () {
    if (!creation) {
        gm.theword = document.getElementById('word');
        gm.msg = document.getElementById('msg');
        gm.numberOfguesses = document.getElementById('guessleft');
        gm.resetPressed = document.getElementById('button');
        gm.resetPressed.addEventListener("click", gm.reset);
        document.onkeypress = gm.keyPressed;
        gm.wordstoguess = ['hello', 'welcome', 'this is the way', 'show must goon', 'rock', 'champion', 'summer', 'christmas'];
        creation = true;
    }

    gm.currentword = gm.wordstoguess[Math.floor(Math.random() * gm.wordstoguess.length)];
    gm.guessleft = Math.floor((gm.currentword.length * 0.5) + 2);
    gm.displayguessword();
    gm.printGuessnumber();
    gm.wordsize();

    gm.finalstate = 0;
    gm.str = [];// array of pressed chars
    gm.winstate = false;

}


gm.displayguessword = function () {
    for (i = 0; i < gm.currentword.length; i++) {
        gm.item = document.createElement('div');
        gm.line = document.createElement('div');
        gm.cont = document.createElement('div');

        if (gm.currentword[i] !== ' ') {
            gm.item.innerHTML = '*';
            gm.line.innerHTML = '_';
        }

        gm.item.setAttribute("class", "item");
        gm.item.classList.add("class", "box");
        gm.item.setAttribute("id", "item" + i);

        gm.line.setAttribute("class", "line");
        gm.line.classList.add("class", "box");
        gm.line.setAttribute("id", "line" + i);

        gm.cont.setAttribute("class", "cont");
        gm.cont.setAttribute("id", "cont" + i);

        gm.cont.append(gm.item);
        gm.cont.append(gm.line);
        gm.theword.append(gm.cont);
    }

}

gm.printGuessnumber = function () {

    gm.numberOfguesses.innerHTML = 'Guesses left: ' + gm.guessleft;
}

gm.wordsize = function () {
    gm.wordlenght = 0;
    for (i = 0; i < gm.currentword.length; i++) {
        if (gm.currentword[i] !== ' ') {
            gm.wordlenght++;
        }
    }
}


gm.keyPressed = function (e) {

    if (!gm.winstate) {
        e = e || window.event;

        //Other browsers (mostly old IE) instead put the event data in window.event (which is accessed here with just event, 
        //which is risky since that relies on there being no local variable with that name)
        //Next, e = e || event; is a standard way of saying "if the parameter was not passed, default it to whatever's after the ||". 
        //In this case, if the event parameter is not passed, then it looks for the global variable.
        //If e exists, keep e. If it doesn't exist, you are using an older version of IE and we assign the windows.event object to e. 

        gm.charCode = e.charCode || e.keyCode,

            //Most but not all of browsers store the character code in the charCode property.
            //In the keypress event, IE <= 8 stores the character code in the keyCode property.
            //to get the character code corresponding to the keypress, 
            // keypress event object is stored in a variable called e:
            //This will generally return a character code where one exists and 0 otherwise
            //https://unixpapa.com/js/key.html

            gm.character = String.fromCharCode(gm.charCode);

        if (/[a-zA-Z]/.test(gm.character)) {
            gm.ismatch(gm.character);
        }
        else {
            gm.msg.innerHTML = 'you pressed not a char';
            setInterval(gm.clearmsg, 3000);
        }
    }
    else {
        gm.numberOfguesses.innerHTML = "you WIN the game. To play again press Reset or hit Enter";
    }
}

gm.ismatch = function (char) {
    gm.status = 0;
    if (!gm.str.includes(char) && !(gm.guessleft <= 0)) {

        for (j = 0; j < gm.currentword.length; j++) {

            if (char === gm.currentword[j]) {// # this if statement
                gm.str.push(char);
                gm.itemTochange = document.getElementById("item" + j);
                gm.lineTochange = document.getElementById("line" + j);
                gm.itemTochange.innerHTML = char;
                gm.lineTochange.innerHTML = '';
                gm.status = parseInt(gm.status) + 1;
                gm.finalstate++;

                if (gm.finalstate === gm.wordlenght) {
                    gm.numberOfguesses.innerHTML = "you WIN the game";
                    gm.winstate = true;
                }
                gm.guesscounter(gm.status, gm.winstate);
            }
            else {//this else belongs to #
                gm.status = parseInt(gm.status, gm.winstate) + 0;
            }
        }
    }
    else {
        gm.msg.innerHTML = "you pressed that char already";
        setInterval(gm.clearmsg, 3000);
        gm.status = parseInt(gm.status) + 1;//this is for *

    }

    gm.guesscounter(gm.status, gm.winstate);
    // * - to not reduce guessleft number at guesscounter cause it 0 at the beggining of function
}

gm.guesscounter = function (state, win) {
    if (!win) {
        var x = parseInt(state);
        if (x === 0) {
            gm.guessleft--;
            gm.printGuessnumber();
            if (gm.guessleft == 0) {
                gm.numberOfguesses.innerHTML = "you loose your game. To start new one press Reset";
            }
        }
    }
}

gm.reset = function () {

    document.getElementById("word").innerHTML = "";
    gm.init();
}

gm.clearmsg = function () {
    gm.msg.innerHTML = "";
}

gm.init();